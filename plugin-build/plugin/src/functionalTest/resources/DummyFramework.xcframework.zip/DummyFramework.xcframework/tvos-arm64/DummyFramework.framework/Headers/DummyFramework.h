//
//  DummyFramework.h
//  DummyFramework
//
//  Created by Francois Dabonot on 06/11/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for DummyFramework.
FOUNDATION_EXPORT double DummyFrameworkVersionNumber;

//! Project version string for DummyFramework.
FOUNDATION_EXPORT const unsigned char DummyFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DummyFramework/PublicHeader.h>


